Beginner series
--------

The official repository of the ng-newsletter beginner series.

* [part 1](http://www.ng-newsletter.com/posts/beginner2expert-how_to_start.html) in the part1 branch.
