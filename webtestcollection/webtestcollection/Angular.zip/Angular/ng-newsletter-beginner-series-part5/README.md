Beginner series
--------

The official repository of the ng-newsletter beginner series.

To start the app, you'll need to have `python` installed. Simply run the server script:

    ./bin/server.sh

You'll now be serving this repository at http://localhost:8080, so open that up in your browser.

* [part 1](http://www.ng-newsletter.com/posts/beginner2expert-how_to_start.html) in the part1 branch.
* [part 2](http://www.ng-newsletter.com/posts/beginner2expert-scopes.html) in the part2 branch.
* [part 3](http://www.ng-newsletter.com/posts/beginner2expert-data-binding.html) in the part3 branch.
* [part 4 and 5](http://www.ng-newsletter.com/posts/beginner2expert-directives.html) in the part5 branch.

