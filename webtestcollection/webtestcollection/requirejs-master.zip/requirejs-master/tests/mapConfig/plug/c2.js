define({
    name: 'plug!c2'
});
