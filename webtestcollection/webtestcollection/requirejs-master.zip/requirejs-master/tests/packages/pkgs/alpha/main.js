define({
    name: 'alpha'
});