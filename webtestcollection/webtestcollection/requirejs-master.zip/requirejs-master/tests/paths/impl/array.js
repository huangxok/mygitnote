define(['./util'], function (util) {
    return {
        name: 'impl/array',
        utilName: util.name
    };
});
