define({
    name: 'other'
});
