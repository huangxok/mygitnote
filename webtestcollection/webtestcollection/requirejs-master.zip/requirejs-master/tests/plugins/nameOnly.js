
define({
    load: function (name, require, onLoad, config) {
        onLoad({
            name: 'nameOnly'
        });
    }
});
