def(function () {
    return {
        name: 'nine'
    };
});