log("five.js script");
