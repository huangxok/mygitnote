log("three.js script");
