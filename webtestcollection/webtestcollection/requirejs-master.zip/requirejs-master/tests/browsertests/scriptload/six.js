log("six.js script");
