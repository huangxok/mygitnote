
if (typeof define !== 'function') { var define = window.badDefine; }

define("one.js script");
