define(["require", "exports", "module", "program"], function(require, exports, module) {
require('program').monkey = 10;

});
