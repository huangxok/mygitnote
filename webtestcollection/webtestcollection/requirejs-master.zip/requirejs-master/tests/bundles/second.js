define('other', {
    name: 'other'
});
